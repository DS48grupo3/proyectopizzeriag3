using System;

namespace PizzeriaDominio
{
    public class Producto
    {
        public int Id {get; set;}
        public string Nombre {get; set;}
        public int Cantidad {get; set;}
        public float Precio {get; set;}
    }

}