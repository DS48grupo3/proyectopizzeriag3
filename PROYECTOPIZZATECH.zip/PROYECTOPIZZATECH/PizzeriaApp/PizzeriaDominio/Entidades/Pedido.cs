using System;

namespace PizzeriaDominio
{
    public class Pedido
    {
        public int Id {get; set;}
        public Boolean Pago {get; set;}
    }

}